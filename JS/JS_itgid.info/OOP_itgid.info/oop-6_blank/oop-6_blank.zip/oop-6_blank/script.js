console.log('Task 2 isNumber ' + Validate.isNumber(30232000));
console.log('Task 3 isInt ' + Validate.isInt(30232000));
console.log('Task 4 isFloat ' + Validate.isFloat(302320.10));
console.log('Task 5 isChar ' + Validate.isChar('1'));
console.log('Task 6 isString ' + Validate.isString('30232000'));
console.log('Task 7 isBoolean ' + Validate.isBoolean(false));
console.log('Task 8 isArray ' + Validate.isArray([30, 23, 20, 00]));
console.log('Task 9 toMoney ' + Validate.toMoney(30232000));