let butn = new ModernButton(800, 100, '#cddc39', 'Button', 3);
document.body.append(butn.render());