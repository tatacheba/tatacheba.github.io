import logo from "./logo.svg";
import "./App.css";
import In from "./In";
import Out from "./Out";

function App() {
    return (
        <div className="App">
            <In />
            <Out />
        </div>
    );
}

export default App;
