const http = require('http');
const url = require('url');

http.createServer(function (req, res) {
});

function main(req, res){
}

function about(req, res){
}

function cat(req, res){
}

function page404(req, res){
}