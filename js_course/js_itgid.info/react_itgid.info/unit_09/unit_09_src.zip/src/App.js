import "./App.css";
import React from "react";
import Comment2Hook from "./Comment2Hook";
// import PlaceholderPostHook from "./PlaceholderPostHook";
// import CommentHook from "./CommentHook";

function App() {
    return (
        <>
            {/* <PlaceholderPostHook /> */}
            {/* <CommentHook /> */}
            <Comment2Hook />
        </>
    );
}

export default App;
