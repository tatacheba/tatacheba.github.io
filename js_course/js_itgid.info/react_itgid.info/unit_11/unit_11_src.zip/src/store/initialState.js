const initialState = {
    user: [
        {
            passport: "4012 503214",
            name: "Hanna",
            age: 14,
        },
    ],
};
export default initialState;
